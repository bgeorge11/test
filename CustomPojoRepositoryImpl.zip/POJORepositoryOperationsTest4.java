package com.marklogic.test.suite1.pojo;

import java.io.FileNotFoundException;

import org.junit.Test;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.marklogic.client.DatabaseClient;
import com.marklogic.client.DatabaseClientFactory;
import com.marklogic.client.pojo.PojoRepository;
import com.marklogic.client.query.StructuredQueryBuilder;
import com.marklogic.client.query.StructuredQueryDefinition;
import com.marklogic.test.suite1.AbstractApiTest;

// illustrates how to write POJOs to the database
@Configuration
@PropertySource(value = { "classpath:contentpump.properties",
		"classpath:user.properties" }, ignoreResourceNotFound = true)
public class POJORepositoryOperationsTest4 extends AbstractApiTest {

	private String COLLECTION_NAME = "";
	String DB_NAME = "";

	@Test
	public void doPojoRepositoryOperationsTest() throws FileNotFoundException {

		COLLECTION_NAME = java.util.UUID.randomUUID().toString();
		// create the client
		DatabaseClient client = DatabaseClientFactory.newClient("localhost", 8000, "ml9-unit-test-demo-4",
				new DatabaseClientFactory.DigestAuthContext("admin", "admin"));

		User shauna = new User();
		shauna.setName("Shauna Weber");
		shauna.setAddress("760 Forest Place, Glenshaw, Michigan, 1175");
		shauna.setAbout(
				"Kitsch fingerstache XOXO, Carles chambray 90's meh cray disrupt Tumblr. Biodiesel craft beer sartorial meh put a bird on it, literally keytar blog vegan paleo. Chambray messenger bag +1 hoodie, try-hard actually banjo bespoke distillery pour-over Godard Thundercats organic. Kitsch wayfarers Pinterest American Apparel. Hella Shoreditch blog, shabby chic iPhone tousled paleo before they sold out keffiyeh Portland Marfa twee dreamcatcher. 8-bit Vice post-ironic plaid. Cornhole Schlitz blog direct trade lomo Pinterest.");
		shauna.setActive(true);
		shauna.setBalance(2774.31);
		shauna.setGender("female");
		shauna.setAge(29);
		
		User peters = new User();
		peters.setName("Peters Barnett");
		peters.setAddress("749 Green Street, Tyro, Illinois, 2856");
		peters.setAbout(
				"Letterpress Echo Park fashion axe occupy whatever before they sold out, Pinterest pickled cliché. Ethnic stumptown food truck wolf, ethical Helvetica Marfa hashtag. Echo Park photo booth banh mi ennui, organic VHS 8-bit fixie. Skateboard irony dreamcatcher mlkshk iPhone cliche. Flannel ennui YOLO artisan tofu. Hashtag irony Shoreditch letterpress, selvage scenester YOLO. Locavore fap bicycle rights, drinking vinegar Tonx bespoke paleo 3 wolf moon readymade direct trade ugh wolf asymmetrical beard plaid.");
		peters.setActive(false);
		peters.setBalance(1787.45);
		peters.setGender("male");
		peters.setAge(38);
		peters.getTags().add(new Tag("ex"));
		peters.getTags().add(new Tag("ex"));
		peters.getTags().add(new Tag("ut"));
		
		
		shauna.setGUID("user001");
		peters.setGUID("user002");

		PojoRepository<User, String> userRepo = client.newPojoRepository(User.class, String.class);
		
		userRepo.write(shauna, "myCollection1");
		userRepo.write(peters, "myCollection1");
		
		User resultUser = userRepo.read(shauna.getGUID());
		
		assertEquals("Shauna Weber", resultUser.getName());

	}
}
